ACHTUNG: Für die Testfunktionen wurde Pylint nicht beachtet und nicht deaktiviert!

Conda-Error in Testlogs ist nicht bekannt, jedoch sind alle Tests einwandfrei.



